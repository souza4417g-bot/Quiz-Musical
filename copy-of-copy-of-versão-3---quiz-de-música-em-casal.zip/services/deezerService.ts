
import { Artist, Song } from '../types';

/**
 * Since Deezer doesn't allow direct CORS for their search,
 * we use a JSONP approach wrapped in a Promise.
 */
export async function searchSongsByArtist(artist: Artist): Promise<Song[]> {
  return new Promise((resolve) => {
    const callbackName = `deezer_cb_${Math.random().toString(36).slice(2, 11)}`;
    const script = document.createElement('script');
    
    // We limit to 10 tracks per artist to find a good variety
    const url = `https://api.deezer.com/search?q=artist:"${encodeURIComponent(artist.name)}"&order=RANKING&limit=10&output=jsonp&callback=${callbackName}`;
    
    (window as any)[callbackName] = (data: any) => {
      const results = data?.data || [];
      const songs: Song[] = results
        .filter((s: any) => s.preview) // Must have audio
        .map((s: any) => ({
          title: s.title.split('(')[0].split('-')[0].trim(), // Clean titles
          artist: s.artist.name,
          preview: s.preview,
          albumCover: s.album?.cover_medium || '',
          category: artist.cat,
          gender: artist.gender
        }));
      
      resolve(songs);
      delete (window as any)[callbackName];
      document.body.removeChild(script);
    };

    script.src = url;
    script.onerror = () => {
      resolve([]);
      delete (window as any)[callbackName];
      if (document.body.contains(script)) document.body.removeChild(script);
    };
    document.body.appendChild(script);
  });
}