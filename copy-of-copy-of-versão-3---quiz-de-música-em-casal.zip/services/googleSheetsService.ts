
import { User, HistoryRecord } from '../types';

// ============================================================================
// CONFIGURAÇÃO: Coloque a URL do seu Google Apps Script (Web App) aqui
// ============================================================================
const SHEET_API_URL = 'https://script.google.com/macros/s/AKfycbwYf9XKjzf3fO2ApZ5nw7N7Lou6oI5lYy9LMxFconNRVictfFLqRe9SHR0XAlpCKBC9IQ/exec'; 

interface SheetPayload {
  action: 'SYNC_USER' | 'LOG_MATCH';
  payload: any;
}

export const googleSheetsService = {
  /**
   * Busca todos os usuários da planilha para validação global.
   * Nota: O fetch GET segue redirecionamentos do Google automaticamente.
   * Não usamos 'no-cors' aqui porque precisamos ler a resposta.
   */
  getAllUsers: async (): Promise<User[]> => {
    if (SHEET_API_URL.includes('COLE_SUA_URL')) return [];

    try {
      const response = await fetch(SHEET_API_URL);
      if (!response.ok) throw new Error('Falha na conexão com a planilha');
      
      const data = await response.json();
      if (Array.isArray(data)) {
        return data as User[];
      }
      return [];
    } catch (error) {
      console.error('[Sheets] Erro ao buscar usuários:', error);
      return [];
    }
  },

  /**
   * Envia dados para o Google Sheets.
   */
  send: async (data: SheetPayload) => {
    if (SHEET_API_URL.includes('COLE_SUA_URL')) {
      console.warn('Google Sheets URL não configurada em services/googleSheetsService.ts');
      return;
    }

    try {
      await fetch(SHEET_API_URL, {
        method: 'POST',
        mode: 'no-cors', 
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      console.log(`[Sheets] Ação ${data.action} enviada com sucesso.`);
    } catch (error) {
      console.error('[Sheets] Erro ao enviar dados:', error);
    }
  },

  syncUser: (user: User) => {
    // Enviamos também a senha para permitir validação futura, se desejar
    const payload = {
      ...user,
      // Se quiser manter a senha privada na planilha, remova ou hash antes de enviar
      // password: user.password 
    };

    googleSheetsService.send({
      action: 'SYNC_USER',
      payload: payload
    });
  },

  logMatch: (record: HistoryRecord, p1Name: string, p2Name: string) => {
    const matchData = {
      ...record,
      p1Name,
      p2Name
    };

    googleSheetsService.send({
      action: 'LOG_MATCH',
      payload: matchData
    });
  }
};
