
import { User, DailyChallenge, Genre } from '../types';
import { googleSheetsService } from './googleSheetsService';
import { THEMES, BADGES, SHOP_ITEMS } from '../constants';

const DB_KEY = 'quiz_users_db';
const SESSION_KEY = 'quiz_current_session';

// XP required for next level formula: Level * 100
export const getXpForNextLevel = (level: number) => level * 100;

const createDailyChallenge = (): DailyChallenge => {
  const types: ('play' | 'win' | 'score')[] = ['play', 'win', 'score'];
  const type = types[Math.floor(Math.random() * types.length)];
  let target = 0;
  let rewardXp = 0;
  let rewardCoins = 0;
  let desc = "";

  if (type === 'play') {
    target = 3;
    rewardXp = 200;
    rewardCoins = 100;
    desc = "Jogue 3 partidas completas";
  } else if (type === 'win') {
    target = 1;
    rewardXp = 300;
    rewardCoins = 150;
    desc = "Vença 1 partida";
  } else {
    target = 50;
    rewardXp = 250;
    rewardCoins = 120;
    desc = "Faça 50 pontos em uma rodada";
  }

  return {
    date: new Date().toISOString().split('T')[0],
    description: desc,
    target,
    progress: 0,
    completed: false,
    rewardXp,
    rewardCoins,
    type
  };
};

// Helper para inicializar campos novos em usuários antigos
const normalizeUser = (user: any): User => {
  const normalized = { ...user };
  if (!normalized.coins) normalized.coins = 0;
  if (!normalized.inventory) normalized.inventory = { hints: 0, skips: 0, lives: 0 };
  if (!normalized.badges) normalized.badges = [];
  if (!normalized.stats) {
    normalized.stats = { 
      totalMatches: normalized.matches || 0, 
      totalWins: normalized.wins || 0,
      genreCounts: {},
      highestRoundSurvival: 0,
      totalCoinsEarned: 0
    };
  }
  if (!normalized.dailyChallenge || normalized.dailyChallenge.date !== new Date().toISOString().split('T')[0]) {
    normalized.dailyChallenge = createDailyChallenge();
  }
  return normalized;
};

export const userService = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(DB_KEY);
    return data ? JSON.parse(data).map(normalizeUser) : [];
  },

  saveUsers: (users: User[]) => {
    localStorage.setItem(DB_KEY, JSON.stringify(users));
  },

  register: async (username: string, password: string, avatar: string): Promise<{ success: boolean; message?: string; user?: User }> => {
    try {
      const localUsers = userService.getUsers();
      if (localUsers.find(u => u.username.toLowerCase() === username.toLowerCase())) {
        return { success: false, message: 'Usuário já existe neste dispositivo!' };
      }

      const remoteUsers = await googleSheetsService.getAllUsers();
      if (remoteUsers.find(u => u.username.toLowerCase() === username.toLowerCase())) {
        return { success: false, message: 'Usuário já existe em outro dispositivo! Tente fazer Login.' };
      }

      const newUser: User = {
        id: Date.now().toString(),
        username,
        password,
        avatar,
        xp: 0,
        level: 1,
        matches: 0,
        wins: 0,
        currentThemeId: THEMES[0].id,
        coins: 100, // Bônus inicial
        inventory: { hints: 1, skips: 1, lives: 0 },
        badges: [],
        dailyChallenge: createDailyChallenge(),
        stats: {
          totalMatches: 0,
          totalWins: 0,
          genreCounts: {},
          highestRoundSurvival: 0,
          totalCoinsEarned: 100
        }
      };

      localUsers.push(newUser);
      userService.saveUsers(localUsers);
      localStorage.setItem(SESSION_KEY, JSON.stringify(newUser.id));
      
      const userToSync = { ...newUser, password };
      googleSheetsService.syncUser(userToSync);

      return { success: true, user: newUser };
    } catch (e) {
      console.error(e);
      return { success: false, message: 'Erro de conexão. Tente novamente.' };
    }
  },

  login: async (username: string, password: string): Promise<{ success: boolean; message?: string; user?: User }> => {
    if (username.toLowerCase() === 'admin' && password === 'admin') {
       const adminUser = normalizeUser({
         id: 'admin_test_user_lvl30',
         username: 'Admin Master',
         password: 'admin',
         avatar: '👑',
         xp: 1500,
         level: 30,
         matches: 500,
         wins: 499,
         currentThemeId: 'dark',
         coins: 9999,
         inventory: { hints: 99, skips: 99, lives: 10 },
         badges: ['veteran', 'rich']
       });

       const localUsers = userService.getUsers();
       const existingIndex = localUsers.findIndex(u => u.id === adminUser.id);
       if (existingIndex >= 0) {
         localUsers[existingIndex] = adminUser;
       } else {
         localUsers.push(adminUser);
       }
       userService.saveUsers(localUsers);
       localStorage.setItem(SESSION_KEY, JSON.stringify(adminUser.id));
       return { success: true, user: adminUser };
    }

    try {
      let localUsers = userService.getUsers();
      let localUser = localUsers.find(u => u.username.toLowerCase() === username.toLowerCase());
      
      if (localUser && localUser.password === password) {
        localUser = normalizeUser(localUser); // Ensure new fields
        // Update local storage with normalized user
        const index = localUsers.findIndex(u => u.id === localUser!.id);
        localUsers[index] = localUser;
        userService.saveUsers(localUsers);

        localStorage.setItem(SESSION_KEY, JSON.stringify(localUser.id));
        googleSheetsService.syncUser(localUser); 
        return { success: true, user: localUser };
      }

      const remoteUsers = await googleSheetsService.getAllUsers();
      const remoteUser = remoteUsers.find(u => u.username.toLowerCase() === username.toLowerCase());

      if (remoteUser) {
        if (remoteUser.password === password) {
          const normalizedRemote = normalizeUser(remoteUser);
          localUsers = localUsers.filter(u => u.username.toLowerCase() !== username.toLowerCase());
          localUsers.push(normalizedRemote);
          userService.saveUsers(localUsers);
          localStorage.setItem(SESSION_KEY, JSON.stringify(normalizedRemote.id));
          return { success: true, user: normalizedRemote };
        } else {
           return { success: false, message: 'Senha incorreta.' };
        }
      }

    } catch (e) {
      console.error("Erro no login:", e);
      return { success: false, message: 'Erro ao conectar com o servidor.' };
    }

    return { success: false, message: 'Usuário não encontrado ou senha incorreta.' };
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  },

  getCurrentUser: (): User | null => {
    const id = localStorage.getItem(SESSION_KEY);
    if (!id) return null;
    const users = userService.getUsers();
    return users.find(u => u.id === JSON.parse(id)) || null;
  },

  updateAfterMatch: (userId: string, isWin: boolean, score: number, genre: Genre, roundReached: number, gameStyle: 'rounds' | 'survival') => {
    const users = userService.getUsers();
    const index = users.findIndex(u => u.id === userId);
    
    if (index === -1) return null;
    const user = users[index];

    // 1. Basic Stats
    let xpGain = isWin ? 100 : 20;
    if (!isWin && score > 0) xpGain += 10; // Consolation
    xpGain += Math.floor(score * 2);
    
    let coinsGain = isWin ? 50 : 10;
    if (gameStyle === 'survival') coinsGain += roundReached * 5;
    
    user.xp += xpGain;
    user.coins += coinsGain;
    user.matches += 1;
    if (isWin) user.wins += 1;
    
    // 2. Advanced Stats
    user.stats.totalMatches += 1;
    if (isWin) user.stats.totalWins += 1;
    user.stats.totalCoinsEarned += coinsGain;
    user.stats.genreCounts[genre] = (user.stats.genreCounts[genre] || 0) + 1;
    if (gameStyle === 'survival' && roundReached > user.stats.highestRoundSurvival) {
      user.stats.highestRoundSurvival = roundReached;
    }

    // 3. Daily Challenge Check
    if (!user.dailyChallenge.completed) {
       let progress = 0;
       if (user.dailyChallenge.type === 'play') progress = 1;
       if (user.dailyChallenge.type === 'win' && isWin) progress = 1;
       if (user.dailyChallenge.type === 'score') progress = score; // Cumulative score? Or single match? Assuming cumulative for simplicity or target is small
       
       // For 'score', let's make it cumulative
       if (user.dailyChallenge.type === 'score') {
         user.dailyChallenge.progress += score;
       } else {
         user.dailyChallenge.progress += progress;
       }

       if (user.dailyChallenge.progress >= user.dailyChallenge.target) {
         user.dailyChallenge.completed = true;
         user.xp += user.dailyChallenge.rewardXp;
         user.coins += user.dailyChallenge.rewardCoins;
       }
    }

    // 4. Badges Check
    BADGES.forEach(badge => {
      if (!user.badges.includes(badge.id)) {
        if (badge.condition(user)) {
          user.badges.push(badge.id);
        }
      }
    });

    // 5. Level Up
    let leveledUp = false;
    let required = getXpForNextLevel(user.level);
    while (user.xp >= required) {
      user.xp -= required;
      user.level += 1;
      leveledUp = true;
      required = getXpForNextLevel(user.level);
    }

    users[index] = user;
    userService.saveUsers(users);
    googleSheetsService.syncUser(user);

    return { 
      leveledUp, 
      xpGained: xpGain, 
      coinsGained: coinsGain,
      challengeCompleted: user.dailyChallenge.completed && user.dailyChallenge.progress >= user.dailyChallenge.target // Rough check, ideal is to track transition
    };
  },

  purchaseItem: (userId: string, itemId: string) => {
    const users = userService.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index === -1) return false;
    
    const user = users[index];
    const item = SHOP_ITEMS.find(i => i.id === itemId);
    
    if (!item || user.coins < item.price) return false;
    
    user.coins -= item.price;
    // @ts-ignore
    user.inventory[item.key] = (user.inventory[item.key] || 0) + 1;
    
    users[index] = user;
    userService.saveUsers(users);
    googleSheetsService.syncUser(user);
    return true;
  },

  addXp: (userId: string, xpAmount: number, isWin: boolean) => {
      // Legacy wrapper, use updateAfterMatch instead for full logic
      // But keeping it for simple calls if needed
      return { newLevel: 0, leveledUp: false, newXp: 0 }; 
  },

  updateTheme: (userId: string, themeId: string): User | null => {
    const users = userService.getUsers();
    const index = users.findIndex(u => u.id === userId);
    
    if (index === -1) return null;

    const user = users[index];
    user.currentThemeId = themeId;

    users[index] = user;
    userService.saveUsers(users);
    
    googleSheetsService.syncUser(user);
    
    return user;
  }
};
